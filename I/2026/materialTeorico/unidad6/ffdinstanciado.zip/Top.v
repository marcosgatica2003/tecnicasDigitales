`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date:    18:59:12 09/23/2026 
// Design Name: 
// Module Name:    Top 
// Project Name: 
// Target Devices: 
// Tool versions: 
// Description: FFD instanciado 4 veces para realizar un contado Jonson sincrono.
// Se puede observar que la salida del �ltimo FFD entra negado al 1er FFD
//
// Dependencies: 
//
// Revision: 
// Revision 0.01 - File Created
// Additional Comments: 
//
//////////////////////////////////////////////////////////////////////////////////
module Top(
    input clk,
    input reset,
    output [3:0] Q
    );

// Instantiate the module
FFD instance_name_3 (
    .clk(clk), 
    .reset(reset), 
    .iD(Q[2]), 
    .oQ(Q[3])
    );


// Instantiate the module
FFD instance_name_2 (
    .clk(clk), 
    .reset(reset), 
    .iD(Q[1]), 
    .oQ(Q[2])
    );


// Instantiate the module
FFD instance_name_1 (
    .clk(clk), 
    .reset(reset), 
    .iD(Q[0]), 
    .oQ(Q[1])
    );


// Instantiate the module
FFD instance_name_0 (
    .clk(clk), 
    .reset(reset), 
    .iD(~Q[3]), 
    .oQ(Q[0])
    );


endmodule
