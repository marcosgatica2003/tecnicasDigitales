`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date:    18:53:02 09/23/2026 
// Design Name: 
// Module Name:    FFD 
// Project Name: 
// Target Devices: 
// Tool versions: 
// Description: 
//
// Dependencies: 
//
// Revision: 
// Revision 0.01 - File Created
// Additional Comments: 
//
//////////////////////////////////////////////////////////////////////////////////
module FFD(
    input clk,
    input reset,
    input iD,
    output reg oQ
    );

// Usage of asynchronous resets may negatively impact FPGA resources
// and timing. In general faster and smaller FPGA designs will
// result from not using asynchronous resets. Please refer to
// the Synthesis and Simulation Design Guide for more information.

   always @(posedge clk or posedge reset)
      if (reset) begin
         oQ <= 1'b0;
      end else begin
         oQ <= iD;
      end
						

endmodule
