`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date:    19:14:36 09/23/2026 
// Design Name: 
// Module Name:    Top2 
// Project Name: 
// Target Devices: 
// Tool versions: 
// Description: 
//
// Dependencies: 
//
// Revision: 
// Revision 0.01 - File Created
// Additional Comments: 
//
//////////////////////////////////////////////////////////////////////////////////
module Top2(
    input clk,
    input reset,
    output [3:0] Q
    );


// Instantiate the module
FFD instance_name_3 (
    .clk(Q[2]), 
    .reset(reset), 
    .iD(~Q[3]), 
    .oQ(Q[3])
    );

// Instantiate the module
FFD instance_name_2 (
    .clk(Q[1]), 
    .reset(reset), 
    .iD(~Q[2]), 
    .oQ(Q[2])
    );

// Instantiate the module
FFD instance_name_1 (
    .clk(Q[0]), 
    .reset(reset), 
    .iD(~Q[1]), 
    .oQ(Q[1])
    );

// Instantiate the module
FFD instance_name_0 (
    .clk(clk), 
    .reset(reset), 
    .iD(~Q[0]), 
    .oQ(Q[0])
    );


endmodule
