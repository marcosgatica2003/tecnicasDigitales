`timescale 1ns / 1ps

////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer:
//
// Create Date:   19:04:15 09/23/2026
// Design Name:   Top
// Module Name:   D:/Dropbox/00 Sergio/03 UTN/Academico/TD1/Verilog_Rev2/2026/FFD_Instanciado/Top_VTF.v
// Project Name:  FFD_Instanciado
// Target Device:  
// Tool versions:  
// Description: 
//
// Verilog Test Fixture created by ISE for module: Top
//
// Dependencies:
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
////////////////////////////////////////////////////////////////////////////////

module Top_VTF;

	// Inputs
	reg clk;
	reg reset;

	// Outputs
	wire [3:0] Q;

	// Instantiate the Unit Under Test (UUT)
	Top uut (
		.clk(clk), 
		.reset(reset), 
		.Q(Q)
	);


   // Note: CLK must be defined as a reg when using this method
   
   parameter PERIOD = 65;

   always begin
      clk = 1'b0;
      #(PERIOD/2) clk = 1'b1;
      #(PERIOD/2);
   end  
				
	initial begin
		// Initialize Inputs
		clk = 0;
		reset = 0;

		// Wait 100 ns for global reset to finish
		#100;
        
		// Add stimulus here
		// Wait 100 ns for global reset to finish
		#100;
		#15;
        
		// Add stimulus here
		reset = 1;
		#100;
		reset = 0;
		#100;

		#500;
		reset = 1;
		#12;
		reset = 0;
		#500;


	end
      
endmodule

