`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date:    19:44:30 09/23/2026 
// Design Name: 
// Module Name:    Top4 
// Project Name: 
// Target Devices: 
// Tool versions: 
// Description: 
//
// Dependencies: 
//
// Revision: 
// Revision 0.01 - File Created
// Additional Comments: 
//
//////////////////////////////////////////////////////////////////////////////////
module Top4 #(
     parameter N = 3                 // cantidad de FFD encadenados
    )(
    input  clk,
    input  Reset,
    output [N-1:0] Q
    );

    genvar i;
    generate
        for (i = 0; i < N; i = i + 1) begin : ffd_chain

            if (i == 0) begin : primer_ffd
                // el primer FFD recibe la realimentaci�n negada del �ltimo bit
                FFD ffd_inst (
                    .clk   (clk),
                    .reset (Reset),
                    .iD    (~Q[0]),
                    .oQ    (Q[0])
                );
            end else begin : resto_ffd
                // cada FFD siguiente recibe la salida del anterior
                FFD ffd_inst (
                    .clk   (Q[i-1]),
                    .reset (Reset),
                    .iD    (~Q[i]),
                    .oQ    (Q[i])
                );
            end

        end
    endgenerate

endmodule
