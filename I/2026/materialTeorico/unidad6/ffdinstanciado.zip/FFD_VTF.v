`timescale 1ns / 1ps

////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer:
//
// Create Date:   18:55:31 09/23/2026
// Design Name:   FFD
// Module Name:   D:/Dropbox/00 Sergio/03 UTN/Academico/TD1/Verilog_Rev2/2026/FFD_Instanciado/FFD_VTF.v
// Project Name:  FFD_Instanciado
// Target Device:  
// Tool versions:  
// Description: 
//
// Verilog Test Fixture created by ISE for module: FFD
//
// Dependencies:
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
////////////////////////////////////////////////////////////////////////////////

module FFD_VTF;

	// Inputs
	reg clk;
	reg reset;
	reg iD;

	// Outputs
	wire oQ;

	// Instantiate the Unit Under Test (UUT)
	FFD uut (
		.clk(clk), 
		.reset(reset), 
		.iD(iD), 
		.oQ(oQ)
	);

   // Note: CLK must be defined as a reg when using this method
   
   parameter PERIOD = 60;

   always begin
      clk = 1'b0;
      #(PERIOD/2) clk = 1'b1;
      #(PERIOD/2);
   end  
				
	initial begin
		// Initialize Inputs
		clk = 0;
		reset = 0;
		iD = 0;

		// Wait 100 ns for global reset to finish
		#125;
        
		// Add stimulus here
		reset = 1;
		#100;
		reset = 0;
		#100;
		iD = 1;
		#300;
		iD = 0;
		#300;

	end
      
endmodule

