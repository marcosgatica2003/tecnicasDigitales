`timescale 1ns / 1ps

////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer:
//
// Create Date:   19:18:14 09/23/2026
// Design Name:   Top2
// Module Name:   D:/Dropbox/00 Sergio/03 UTN/Academico/TD1/Verilog_Rev2/2026/FFD_Instanciado/Top2_VTF.v
// Project Name:  FFD_Instanciado
// Target Device:  
// Tool versions:  
// Description: 
//
// Verilog Test Fixture created by ISE for module: Top2
//
// Dependencies:
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
////////////////////////////////////////////////////////////////////////////////

module Top2_VTF;

	// Inputs
	reg clk;
	reg reset;

	// Outputs
	wire [3:0] Q;

	// Instantiate the Unit Under Test (UUT)
	Top2 uut (
		.clk(clk), 
		.reset(reset), 
		.Q(Q)
	);

   // Note: CLK must be defined as a reg when using this method
   
   parameter PERIOD = 60;

   always begin
      clk = 1'b0;
      #(PERIOD/2) clk = 1'b1;
      #(PERIOD/2);
   end  
				
	initial begin
		// Initialize Inputs
		clk = 0;
		reset = 0;

		// Wait 100 ns for global reset to finish
		#100;
        
		// Add stimulus here
		reset = 1;
		#50;
		reset = 0;
		#500;

	end
      
endmodule

