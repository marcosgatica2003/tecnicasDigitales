`timescale 1ns / 1ps

////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer:
//
// Create Date:   19:53:10 09/23/2026
// Design Name:   Top4
// Module Name:   D:/Dropbox/00 Sergio/03 UTN/Academico/TD1/Verilog_Rev2/2026/FFD_Instanciado/Top4_VTF.v
// Project Name:  FFD_Instanciado
// Target Device:  
// Tool versions:  
// Description: 
//
// Verilog Test Fixture created by ISE for module: Top4
//
// Dependencies:
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
////////////////////////////////////////////////////////////////////////////////

module Top4_VTF;


    // Cambiando este par�metro se prueba el circuito con distinta cantidad de FFD
    parameter N = 3;
    parameter CLK_PERIOD = 500;
 
    reg  clk;
    reg  Reset;
    wire [N-1:0] Q;
 
    // Instancia del DUT (Device Under Test)
    Top4 #(
        .N(N)
    ) DUT (
        .clk   (clk),
        .Reset (Reset),
        .Q     (Q)
    );
 
    // Generaci�n de clock
    initial clk = 1'b0;
    always #(CLK_PERIOD/2) clk = ~clk;
 
    // Est�mulos
    initial begin
        Reset = 1'b1;
        #(CLK_PERIOD * 2);
        Reset = 1'b0;
 
        // Un contador de Johnson de N bits tiene 2*N estados distintos.
        // Simulamos un par de ciclos completos para verificar la secuencia.
        #(CLK_PERIOD * 2 * N * 2);
 
        $finish;
    end
 
    // Monitoreo
    initial begin
        $display("N = %0d", N);
        $monitor("t=%0t | Reset=%b | Q=%b", $time, Reset, Q);
    end
 
endmodule
 